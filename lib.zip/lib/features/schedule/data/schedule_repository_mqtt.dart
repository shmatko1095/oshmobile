// lib/features/schedule/data/schedule_repository_mqtt.dart
//
// ScheduleRepository implementation backed by DeviceMqttRepo + ScheduleTopics (shadow pattern).
//
// Contract used here (align device firmware to it):
// - To fetch:
//   publishJson(getReq(deviceId), {"reqId": "..."}?) and wait for a retained/next JSON on reported(deviceId).
// - To save:
//   publishJson(desired(deviceId), {"reqId":"...", "mode":"...", "lists":{...}})
//   then wait for reported(deviceId) which either echoes this reqId OR simply republishes snapshot.
//
// IMPORTANT CHANGES:
// - Incoming payloads may be PARTIAL (e.g., only "weekly" list). We decode a *_PartialSnapshot*
//   and MERGE it with the last full snapshot (_last[deviceId]) or with an empty baseline.
// - Empty list for a mode IS valid and replaces the existing list.
// - Missing keys DO NOT override anything.
//
// Comments are in English by default.

import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:oshmobile/core/network/mqtt/device_mqtt_repo.dart';
import 'package:oshmobile/features/schedule/data/schedule_topics.dart';
import 'package:oshmobile/features/schedule/domain/models/calendar_snapshot.dart';
import 'package:oshmobile/features/schedule/domain/models/schedule_models.dart';
import 'package:oshmobile/features/schedule/domain/repositories/schedule_repository.dart';

/// Internal structure representing a *partial* schedule update.
/// - [mode] == null -> 'mode' was not present in payload (do not change).
/// - [listsPatch] == null -> 'lists' object not present at all (do not change lists).
///   When [listsPatch] is non-null, only modes included in the map should be replaced.
///   Empty list is a valid replacement.
class _PartialSnapshot {
  final CalendarMode? mode;
  final Map<CalendarMode, List<SchedulePoint>>? listsPatch;

  const _PartialSnapshot({this.mode, this.listsPatch});
}

class ScheduleRepositoryMqtt implements ScheduleRepository {
  final DeviceMqttRepo _mqtt;
  final ScheduleTopics _topics;
  final Duration timeout;

  final Map<String, StreamController<CalendarSnapshot>> _ctrls = {};
  final Map<String, StreamSubscription> _subs = {};
  final Map<String, int> _refs = {};
  final Map<String, CalendarSnapshot> _last = {};

  ScheduleRepositoryMqtt(
    this._mqtt,
    this._topics, {
    this.timeout = const Duration(seconds: 6),
  });

  @override
  Future<CalendarSnapshot> fetchAll(String deviceId) async {
    final reportedTopic = _topics.reported(deviceId);
    final getTopic = _topics.getReq(deviceId);

    // 1) Subscribe to reported (will receive retained if exists).
    final stream = _mqtt.subscribeJson(reportedTopic);

    // 2) Ask device to publish current snapshot (race-safe).
    final reqId = _newReqId();
    unawaited(_mqtt.publishJson(getTopic, {'reqId': reqId}));

    // 3) Take the first reported we see (retained or fresh) and MERGE.
    final msg = await stream.first.timeout(timeout);
    final partial = _decodePartial(msg.payload);
    final base = _last[deviceId] ?? CalendarSnapshot.empty();
    final merged = base.mergePartial(mode: partial.mode, listsPatch: partial.listsPatch);

    _last[deviceId] = merged;
    return merged;
  }

  @override
  Future<void> saveAll(String deviceId, CalendarSnapshot snapshot) async {
    final reportedTopic = _topics.reported(deviceId);
    final desiredTopic = _topics.desired(deviceId);

    final reqId = _newReqId();
    final payload = {
      'reqId': reqId,
      'mode': snapshot.mode.id,
      'lists': _encodeLists(snapshot.lists),
    };

    // 1) Subscribe to reported to catch echo/republish after desired is sent.
    final repStream = _mqtt.subscribeJson(reportedTopic);

    // 2) Publish desired bundle.
    await _mqtt.publishJson(desiredTopic, payload);

    // 3) Prefer correlation by reqId; otherwise accept first next reported.
    try {
      await repStream.map((e) => e.payload).firstWhere((p) => _matchesReqId(p, reqId)).timeout(timeout);
    } on TimeoutException {
      // Fallback: any next reported (republish without reqId).
      await repStream.first.timeout(timeout);
    }
  }

  @override
  Stream<CalendarSnapshot> watchSnapshot(String deviceId) {
    // Reuse existing controller if present.
    final existing = _ctrls[deviceId];
    if (existing != null && !existing.isClosed) {
      return existing.stream;
    }

    // Create the controller first, then store it — avoid self-reference issue.
    late final StreamController<CalendarSnapshot> ctrl;
    ctrl = StreamController<CalendarSnapshot>.broadcast(
      onListen: () async {
        // Ref-counting: start MQTT wiring on first listener.
        _refs[deviceId] = (_refs[deviceId] ?? 0) + 1;
        if (_refs[deviceId]! > 1) return;

        final reportedTopic = _topics.reported(deviceId);
        final getTopic = _topics.getReq(deviceId);

        // Subscribe to reported/* and forward to stream as MERGED snapshots.
        _subs[deviceId] = _mqtt.subscribeJson(reportedTopic).listen((msg) {
          final partial = _decodePartial(msg.payload);
          final base = _last[deviceId] ?? CalendarSnapshot.empty();
          final snap = base.mergePartial(mode: partial.mode, listsPatch: partial.listsPatch);
          _last[deviceId] = snap;
          if (!ctrl.isClosed) ctrl.add(snap);
        });

        // Ask for retained snapshot (device may republish current state).
        unawaited(_mqtt.publishJson(getTopic, {'reqId': _newReqId()}));

        // If we already have a cached full snapshot, emit it immediately.
        final cached = _last[deviceId];
        if (cached != null) {
          scheduleMicrotask(() {
            if (!ctrl.isClosed) ctrl.add(cached);
          });
        }
      },
      onCancel: () async {
        // Ref-counting: tear down MQTT on last listener.
        _refs[deviceId] = (_refs[deviceId] ?? 1) - 1;
        if (_refs[deviceId]! <= 0) {
          _refs.remove(deviceId);
          await _subs.remove(deviceId)?.cancel();
          final c = _ctrls.remove(deviceId);
          if (c != null && !c.isClosed) await c.close();
        }
      },
    );

    _ctrls[deviceId] = ctrl;
    return ctrl.stream;
  }

  @override
  Future<void> setMode(String deviceId, CalendarMode mode) async {
    // Keep lists unchanged; use last known snapshot or fetch once.
    final current = _last[deviceId] ?? await fetchAll(deviceId);
    final desired = current.copyWith(mode: mode);

    // Reuse saveAll to honor reqId/ack flow.
    await saveAll(deviceId, desired);
  }

  // ---------------- Partial merge helpers ----------------
  /// Decode incoming payload into *_PartialSnapshot*:
  /// - Only set [mode] if 'mode' exists in payload.
  /// - Build listsPatch ONLY for keys actually present inside 'lists'.
  _PartialSnapshot _decodePartial(dynamic raw) {
    final map = switch (raw) {
      String s => jsonDecode(s) as Map<String, dynamic>,
      Map<String, dynamic> m => m,
      _ => const <String, dynamic>{},
    };

    // Mode: present -> parse; absent -> null (no change)
    CalendarMode? mode;
    if (map.containsKey('mode')) {
      final modeStr = (map['mode'] as String?) ?? '';
      if (modeStr.isNotEmpty) {
        mode = CalendarMode.all.firstWhere(
          (m) => m.id == modeStr,
          orElse: () => CalendarMode.off, // fallback if unknown
        );
      }
    }

    // Lists: patch only for present keys
    Map<CalendarMode, List<SchedulePoint>>? listsPatch;
    final listsAny = map['lists'];
    if (listsAny is Map) {
      final lr = listsAny.cast<String, dynamic>();
      final patch = <CalendarMode, List<SchedulePoint>>{};

      void putIfPresent(CalendarMode m) {
        if (lr.containsKey(m.id)) {
          // Empty list is a valid replacement.
          patch[m] = _sortedDedup(_decodeList(lr[m.id]));
        }
      }

      putIfPresent(CalendarMode.off);
      putIfPresent(CalendarMode.on);
      putIfPresent(CalendarMode.antifreeze);
      putIfPresent(CalendarMode.daily);
      putIfPresent(CalendarMode.weekly);

      if (patch.isNotEmpty) {
        listsPatch = patch;
      }
    }

    return _PartialSnapshot(mode: mode, listsPatch: listsPatch);
  }

  // ---------------- Encoding / Decoding primitives ----------------

  List<SchedulePoint> _decodeList(dynamic v) {
    final list = (v as List?) ?? const [];
    return list.whereType<Map>().map((m) {
      final hh = (m['hh'] as num?)?.toInt() ?? 0;
      final mm = (m['mm'] as num?)?.toInt() ?? 0;
      final d = (m['d'] as num?)?.toInt() ?? WeekdayMask.all;

      // Accept either scalar setpoint or min/max.
      final minVal = (m['min'] as num?)?.toDouble();
      final maxVal = (m['max'] as num?)?.toDouble();
      final a = (minVal ?? maxVal ?? 21.0);
      final b = (maxVal ?? minVal ?? a);

      final lo = a <= b ? a : b;
      final hi = b >= a ? b : a;

      return SchedulePoint(
        time: TimeOfDay(hour: hh.clamp(0, 23), minute: mm.clamp(0, 59)),
        daysMask: d & WeekdayMask.all,
        min: double.parse(lo.toStringAsFixed(1)),
        max: double.parse(hi.toStringAsFixed(1)),
      );
    }).toList();
  }

  Map<String, dynamic> _encodeLists(Map<CalendarMode, List<SchedulePoint>> lists) {
    final out = <String, dynamic>{};
    for (final e in lists.entries) {
      out[e.key.id] = e.value.map(_encodePoint).toList();
    }
    // Ensure all known keys exist (device side may prefer full lists object).
    for (final k in [
      CalendarMode.off.id,
      CalendarMode.on.id,
      CalendarMode.antifreeze.id,
      CalendarMode.daily.id,
      CalendarMode.weekly.id,
    ]) {
      out.putIfAbsent(k, () => <dynamic>[]);
    }
    return out;
  }

  Map<String, dynamic> _encodePoint(SchedulePoint p) => {
        'hh': p.time.hour,
        'mm': p.time.minute,
        'd': p.daysMask,
        'min': p.min,
        'max': p.max,
      };

  List<SchedulePoint> _sortedDedup(List<SchedulePoint> pts) {
    // Deduplicate by (daysMask, hh, mm); last wins.
    final map = <String, SchedulePoint>{};
    for (final p in pts) {
      final key = '${p.daysMask}:${p.time.hour}:${p.time.minute}';
      map[key] = p;
    }
    final out = map.values.toList()
      ..sort((a, b) {
        final ai = pMinutes(a.time);
        final bi = pMinutes(b.time);
        if (ai != bi) return ai.compareTo(bi);
        return a.daysMask.compareTo(b.daysMask);
      });
    return out;
  }

  bool _matchesReqId(dynamic payload, String expected) {
    if (payload == null) return false;
    if (payload is String) return payload == expected;
    if (payload is Map && payload['reqId']?.toString() == expected) return true;

    final meta = (payload is Map) ? payload['meta'] : null;
    if (meta is Map && meta['lastAppliedReqId']?.toString() == expected) return true;

    // support {"data":{"reqId":"..."}} just in case
    final data = (payload is Map) ? payload['data'] : null;
    if (data is Map && data['reqId']?.toString() == expected) return true;

    return false;
  }

  String _newReqId() => DateTime.now().millisecondsSinceEpoch.toString();

  int pMinutes(TimeOfDay t) => t.hour * 60 + t.minute;
}
