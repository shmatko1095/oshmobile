// class Info {
//   final String swVersion;
//   final String hwVersion;
//   final String productionDate;
//
//   const Info({
//     required this.swVersion,
//     required this.hwVersion,
//     required this.productionDate,
//   });
//
//   factory Info.fromJson(Map<String, dynamic>? json) {
//     json = json ?? {};
//     return Info(
//       swVersion: json['swVersion'] ?? "",
//       hwVersion: json['hwVersion'] ?? "",
//       productionDate: json['productionDate'] ?? "",
//     );
//   }
// }
