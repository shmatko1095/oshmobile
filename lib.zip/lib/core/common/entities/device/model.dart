// import 'package:oshmobile/core/common/entities/device/configuration.dart';
// import 'package:oshmobile/core/common/entities/device/manufacturer.dart';
//
// class Model {
//   final String id;
//   final String name;
//   final Manufacturer manufacturer;
//   final Configuration configuration;
//
//   const Model({
//     required this.uuid,
//     required this.name,
//     required this.manufacturer,
//     required this.configuration,
//   });
//
//   factory Model.fromJson(Map<String, dynamic>? json) {
//     json = json ?? {};
//     return Model(
//       uuid: json['uuid'] ?? "",
//       name: json['name'] ?? "",
//       manufacturer: Manufacturer.fromJson(json['manufacturer']),
//       configuration: Configuration.fromJson(json['configuration']),
//     );
//   }
// }
