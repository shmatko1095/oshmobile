class AppConfig {
  final String tenantId;

  const AppConfig({required this.tenantId});
}
