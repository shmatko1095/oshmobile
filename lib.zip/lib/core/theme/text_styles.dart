import 'package:flutter/cupertino.dart';

class TextStyles {
  static const titleStyle = TextStyle(
    fontSize: 37,
    fontWeight: FontWeight.w700,
  );

  static const TextStyle contentStyle = TextStyle(
    fontSize: 16,
    color: CupertinoColors.systemGrey,
  );
}
