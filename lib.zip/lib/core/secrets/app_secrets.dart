class AppSecrets {
  static const oshAccessTokenUrl = "https://auth.oshhome.com/realms/users-dev/protocol/openid-connect/token";
  static const clientSecret = "n9LkmFP3yAsi9azPP5bS5aTCWzgnI59O";
  static const clientId = "oshmobile";
  static const oshApiEndpoint = "https://api.oshhome.com/v1";
}
